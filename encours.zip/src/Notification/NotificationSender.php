<?php

declare(strict_types=1);

namespace App\Notification;

use App\Customer\Domain\Customer;
use App\Notification\Domain\Notification;

class NotificationSender implements NotificationSenderInterface
{
    public function send(Notification $notification, Customer $recipient): void
    {
        $message = sprintf('[%s <%s>] %s', $recipient->name, $recipient->email, $notification);
        $headers = 'From: noreply@example.com' . "\r\n" . 'Reply-To: noreply@example.com' . "\r\n";
        mail($recipient->email, 'Notification', $message, $headers);
    }
}
