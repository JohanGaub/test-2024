<?php

declare(strict_types=1);

namespace App\Tracking\Handler;

use App\Customer\CustomerResolver;
use App\Notification\Domain\Notification;
use App\Notification\NotificationSender;
use App\Tracking\Sdk\MondialRelay\MondialRelayTrackingProvider;

final readonly class MondialRelayTrackingHandler implements TrackingHandlerInterface
{
    public function __construct(
        private MondialRelayTrackingProvider $trackingProvider,
        private NotificationSender           $notificationSender,
        private CustomerResolver             $customerResolver
    )
    {
    }

    public function supports(string $trackingCode): bool
    {
        return str_starts_with($trackingCode, 'MR-');
    }

    public function handle(string $trackingCode): void
    {
//        call notif
//    he is here send notif

        $trackingResponse = $this->trackingProvider->provide($trackingCode);

        $message = new Notification(
            sprintf(
                'New Mondial Relay parcel "%s" received.',
                $trackingResponse->trackingId,
            ));

        $customer = $this->customerResolver->resolveByParcelTrackingId($trackingCode);
        $this->notificationSender->send($message, $customer);
    }
}
