<?php

declare(strict_types=1);

namespace App\Tracking\Handler;

use App\Tracking\Sdk\SoColissimo\ColissimoTrackingProvider;

final readonly class SoColissimoTrackingHandler implements TrackingHandlerInterface
{
    public function __construct(private ColissimoTrackingProvider $trackingProvider)
    {
    }

    public function supports(string $trackingCode): bool
    {
        return str_starts_with($trackingCode, 'SOCO-');
    }

    public function handle(string $trackingCode): void
    {
        $trackingResponse = $this->trackingProvider->provide($trackingCode);

        $message = sprintf(
            'Your Mondial Relay parcel with tracking code "%d" is in status "%s" at address "%s".',
            $trackingResponse->trackingId,
            $trackingResponse->status,
            $trackingResponse->address,
        );
    }
}
