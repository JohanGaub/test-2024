<?php

declare(strict_types=1);

namespace App\Tracking\Handler;

use App\Tracking\Sdk\MondialRelay\MondialRelayTrackingProvider;

final readonly class TrackingHandler implements TrackingHandlerInterface
{
    public function __construct(
        private TrackingProviderInterface $trackingProvider,
        private string $prefix
    ) {
    }

    public function supports(string $trackingCode): bool
    {
        return str_starts_with($trackingCode, $this->prefix);
    }

    public function handle(string $trackingCode): void
    {
        $trackingResponse = $this->trackingProvider->provide($trackingCode);

        $message = sprintf(
            'Your parcel with tracking code "%d" is in status "%s" at address "%s".',
            $trackingResponse->trackingId,
            $trackingResponse->status,
            $trackingResponse->address,
        );
    }
}
